#!/bin/bash

# This works when the alias for matlab 2016b is setup as matlab-2016b
matlab-2016b -nodisplay -nodesktop -r "astrobee; build_Proto4; exit"
