//
// File: aaiehlfccbimimgd_xzlarf.h
//
// Code generated for Simulink model 'est_estimator'.
//
// Model version                  : 1.1142
// Simulink Coder version         : 8.11 (R2016b) 25-Aug-2016
// C/C++ source code generated on : Tue Oct 16 10:06:07 2018
//
#ifndef SHARE_aaiehlfccbimimgd_xzlarf
#define SHARE_aaiehlfccbimimgd_xzlarf
#include "rtwtypes.h"

extern void aaiehlfccbimimgd_xzlarf(int32_T m, int32_T n, int32_T iv0, real32_T
  tau, real32_T C_data[], int32_T ic0, int32_T ldc, real32_T work_data[]);

#endif

//
// File trailer for generated code.
//
// [EOF]
//
