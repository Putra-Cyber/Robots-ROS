//
// File: aiekjmohekfccbaa_eulers_to_quat.h
//
// Code generated for Simulink model 'est_estimator'.
//
// Model version                  : 1.1137
// Simulink Coder version         : 8.9 (R2015b) 13-Aug-2015
// C/C++ source code generated on : Wed May  3 15:13:05 2017
//
#ifndef SHARE_aiekjmohekfccbaa_eulers_to_quat
#define SHARE_aiekjmohekfccbaa_eulers_to_quat
#include "rtwtypes.h"

extern void aiekjmohekfccbaa_eulers_to_quat(real32_T rz, real32_T ry, real32_T
  rx, real32_T quat[4]);

#endif

//
// File trailer for generated code.
//
// [EOF]
//
