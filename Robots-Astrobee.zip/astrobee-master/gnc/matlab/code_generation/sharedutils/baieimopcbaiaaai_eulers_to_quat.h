//
// File: baieimopcbaiaaai_eulers_to_quat.h
//
// Code generated for Simulink model 'est_estimator'.
//
// Model version                  : 1.1142
// Simulink Coder version         : 8.11 (R2016b) 25-Aug-2016
// C/C++ source code generated on : Tue Oct 16 10:06:07 2018
//
#ifndef SHARE_baieimopcbaiaaai_eulers_to_quat
#define SHARE_baieimopcbaiaaai_eulers_to_quat
#include "rtwtypes.h"

extern void baieimopcbaiaaai_eulers_to_quat(real32_T phi, real32_T theta,
  real32_T psi, real32_T quat[4]);

#endif

//
// File trailer for generated code.
//
// [EOF]
//
