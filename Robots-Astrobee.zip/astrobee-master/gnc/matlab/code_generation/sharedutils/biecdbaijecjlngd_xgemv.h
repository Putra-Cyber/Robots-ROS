//
// File: biecdbaijecjlngd_xgemv.h
//
// Code generated for Simulink model 'est_estimator'.
//
// Model version                  : 1.1142
// Simulink Coder version         : 8.11 (R2016b) 25-Aug-2016
// C/C++ source code generated on : Tue Oct 16 10:06:07 2018
//
#ifndef SHARE_biecdbaijecjlngd_xgemv
#define SHARE_biecdbaijecjlngd_xgemv
#include "rtwtypes.h"

extern void biecdbaijecjlngd_xgemv(int32_T m, int32_T n, const real32_T A_data[],
  int32_T ia0, int32_T lda, const real32_T x_data[], int32_T ix0, real32_T
  y_data[]);

#endif

//
// File trailer for generated code.
//
// [EOF]
//
