//
// File: bieckfkfhlnodbie_norm.h
//
// Code generated for Simulink model 'est_estimator'.
//
// Model version                  : 1.1090
// Simulink Coder version         : 8.9 (R2015b) 13-Aug-2015
// C/C++ source code generated on : Mon Mar  6 17:33:02 2017
//
#ifndef SHARE_bieckfkfhlnodbie_norm
#define SHARE_bieckfkfhlnodbie_norm
#include "rtwtypes.h"

extern real32_T bieckfkfhlnodbie_norm(const real32_T x[2]);

#endif

//
// File trailer for generated code.
//
// [EOF]
//
