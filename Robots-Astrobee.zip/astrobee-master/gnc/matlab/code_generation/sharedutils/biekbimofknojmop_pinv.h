//
// File: biekbimofknojmop_pinv.h
//
// Code generated for Simulink model 'est_estimator'.
//
// Model version                  : 1.1137
// Simulink Coder version         : 8.9 (R2015b) 13-Aug-2015
// C/C++ source code generated on : Wed May  3 15:13:05 2017
//
#ifndef SHARE_biekbimofknojmop_pinv
#define SHARE_biekbimofknojmop_pinv
#include "rtwtypes.h"

extern void biekbimofknojmop_pinv(const real32_T A[4], real32_T X[4]);

#endif

//
// File trailer for generated code.
//
// [EOF]
//
