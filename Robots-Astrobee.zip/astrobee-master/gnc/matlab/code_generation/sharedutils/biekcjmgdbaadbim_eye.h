//
// File: biekcjmgdbaadbim_eye.h
//
// Code generated for Simulink model 'est_estimator'.
//
// Model version                  : 1.1142
// Simulink Coder version         : 8.11 (R2016b) 25-Aug-2016
// C/C++ source code generated on : Tue Oct 16 10:06:07 2018
//
#ifndef SHARE_biekcjmgdbaadbim_eye
#define SHARE_biekcjmgdbaadbim_eye
#include "rtwtypes.h"

extern void biekcjmgdbaadbim_eye(real32_T I[36]);

#endif

//
// File trailer for generated code.
//
// [EOF]
//
