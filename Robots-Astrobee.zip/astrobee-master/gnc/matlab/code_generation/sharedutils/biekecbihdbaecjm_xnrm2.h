//
// File: biekecbihdbaecjm_xnrm2.h
//
// Code generated for Simulink model 'est_estimator'.
//
// Model version                  : 1.1142
// Simulink Coder version         : 8.11 (R2016b) 25-Aug-2016
// C/C++ source code generated on : Tue Oct 16 10:06:07 2018
//
#ifndef SHARE_biekecbihdbaecjm_xnrm2
#define SHARE_biekecbihdbaecjm_xnrm2
#include "rtwtypes.h"

extern real32_T biekecbihdbaecjm_xnrm2(int32_T n, const real32_T x_data[],
  int32_T ix0);

#endif

//
// File trailer for generated code.
//
// [EOF]
//
