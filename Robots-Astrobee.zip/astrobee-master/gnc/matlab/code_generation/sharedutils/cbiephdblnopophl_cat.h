//
// File: cbiephdblnopophl_cat.h
//
// Code generated for Simulink model 'sim_model_lib0'.
//
// Model version                  : 1.1142
// Simulink Coder version         : 8.11 (R2016b) 25-Aug-2016
// C/C++ source code generated on : Tue Oct 16 10:08:00 2018
//
#ifndef SHARE_cbiephdblnopophl_cat
#define SHARE_cbiephdblnopophl_cat
#include "rtwtypes.h"

extern void cbiephdblnopophl_cat(const real32_T varargin_2[1500], real32_T y
  [1600]);

#endif

//
// File trailer for generated code.
//
// [EOF]
//
