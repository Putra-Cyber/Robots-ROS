//
// File: cbimbiekfcjmaaie_svd.h
//
// Code generated for Simulink model 'est_estimator'.
//
// Model version                  : 1.1137
// Simulink Coder version         : 8.9 (R2015b) 13-Aug-2015
// C/C++ source code generated on : Wed May  3 15:13:05 2017
//
#ifndef SHARE_cbimbiekfcjmaaie_svd
#define SHARE_cbimbiekfcjmaaie_svd
#include "rtwtypes.h"

extern void cbimbiekfcjmaaie_svd(const real32_T A[16], real32_T U[16], real32_T
  S[16], real32_T V[16]);

#endif

//
// File trailer for generated code.
//
// [EOF]
//
