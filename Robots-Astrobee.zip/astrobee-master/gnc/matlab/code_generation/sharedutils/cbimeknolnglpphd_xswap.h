//
// File: cbimeknolnglpphd_xswap.h
//
// Code generated for Simulink model 'est_estimator'.
//
// Model version                  : 1.1142
// Simulink Coder version         : 8.11 (R2016b) 25-Aug-2016
// C/C++ source code generated on : Tue Oct 16 10:06:07 2018
//
#ifndef SHARE_cbimeknolnglpphd_xswap
#define SHARE_cbimeknolnglpphd_xswap
#include "rtwtypes.h"

extern void cbimeknolnglpphd_xswap(real32_T x[4]);

#endif

//
// File trailer for generated code.
//
// [EOF]
//
