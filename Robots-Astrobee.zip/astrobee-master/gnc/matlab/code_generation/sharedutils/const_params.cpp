//
//  const_params.cpp
//
//  Code generation for model "sim_model_lib0".
//
//  Model version              : 1.1142
//  Simulink Coder version : 8.11 (R2016b) 25-Aug-2016
//  C++ source code generated on : Tue Oct 16 10:08:00 2018

#include "rtwtypes.h"

extern const real_T rtCP_pooled_15LYgUQHWYtd[6];
const real_T rtCP_pooled_15LYgUQHWYtd[6] = { 1.0, 2.0, 3.0, 4.0, 5.0, 6.0 } ;
