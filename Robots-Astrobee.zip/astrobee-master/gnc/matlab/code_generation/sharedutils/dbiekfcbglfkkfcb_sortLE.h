//
// File: dbiekfcbglfkkfcb_sortLE.h
//
// Code generated for Simulink model 'sim_model_lib0'.
//
// Model version                  : 1.1142
// Simulink Coder version         : 8.11 (R2016b) 25-Aug-2016
// C/C++ source code generated on : Tue Oct 16 10:08:00 2018
//
#ifndef SHARE_dbiekfcbglfkkfcb_sortLE
#define SHARE_dbiekfcbglfkkfcb_sortLE
#include "rtwtypes.h"

extern boolean_T dbiekfcbglfkkfcb_sortLE(const real32_T v_data[], const int32_T
  v_sizes[2], const int32_T col[2], int32_T irow1, int32_T irow2);

#endif

//
// File trailer for generated code.
//
// [EOF]
//
