//
// File: djecdbimhdjmdjmg_svd.h
//
// Code generated for Simulink model 'est_estimator'.
//
// Model version                  : 1.1137
// Simulink Coder version         : 8.9 (R2015b) 13-Aug-2015
// C/C++ source code generated on : Wed May  3 15:13:05 2017
//
#ifndef SHARE_djecdbimhdjmdjmg_svd
#define SHARE_djecdbimhdjmdjmg_svd
#include "rtwtypes.h"

extern void djecdbimhdjmdjmg_svd(const real32_T A_data[], const int32_T A_sizes
  [2], real32_T U_data[], int32_T U_sizes[2], real32_T S_data[], int32_T
  S_sizes[2], real32_T V_data[], int32_T V_sizes[2]);

#endif

//
// File trailer for generated code.
//
// [EOF]
//
