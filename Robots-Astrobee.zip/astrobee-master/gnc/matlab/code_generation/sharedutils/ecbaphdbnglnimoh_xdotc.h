//
// File: ecbaphdbnglnimoh_xdotc.h
//
// Code generated for Simulink model 'est_estimator'.
//
// Model version                  : 1.1142
// Simulink Coder version         : 8.11 (R2016b) 25-Aug-2016
// C/C++ source code generated on : Tue Oct 16 10:06:07 2018
//
#ifndef SHARE_ecbaphdbnglnimoh_xdotc
#define SHARE_ecbaphdbnglnimoh_xdotc
#include "rtwtypes.h"

extern real32_T ecbaphdbnglnimoh_xdotc(const real32_T x[4], const real32_T y[4]);

#endif

//
// File trailer for generated code.
//
// [EOF]
//
