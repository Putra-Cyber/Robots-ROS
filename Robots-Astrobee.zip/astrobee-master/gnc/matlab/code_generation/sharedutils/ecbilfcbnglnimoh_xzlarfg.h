//
// File: ecbilfcbnglnimoh_xzlarfg.h
//
// Code generated for Simulink model 'est_estimator'.
//
// Model version                  : 1.1142
// Simulink Coder version         : 8.11 (R2016b) 25-Aug-2016
// C/C++ source code generated on : Tue Oct 16 10:06:07 2018
//
#ifndef SHARE_ecbilfcbnglnimoh_xzlarfg
#define SHARE_ecbilfcbnglnimoh_xzlarfg
#include "rtwtypes.h"

extern real32_T ecbilfcbnglnimoh_xzlarfg(int32_T n, real32_T *alpha1, real32_T
  x_data[], int32_T ix0);

#endif

//
// File trailer for generated code.
//
// [EOF]
//
