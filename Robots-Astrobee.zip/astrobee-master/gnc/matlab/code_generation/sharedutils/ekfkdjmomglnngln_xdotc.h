//
// File: ekfkdjmomglnngln_xdotc.h
//
// Code generated for Simulink model 'fam_force_allocation_module'.
//
// Model version                  : 1.1142
// Simulink Coder version         : 8.11 (R2016b) 25-Aug-2016
// C/C++ source code generated on : Tue Oct 16 10:07:06 2018
//
#ifndef SHARE_ekfkdjmomglnngln_xdotc
#define SHARE_ekfkdjmomglnngln_xdotc
#include "rtwtypes.h"

extern real32_T ekfkdjmomglnngln_xdotc(int32_T n, const real32_T x[72], int32_T
  ix0, const real32_T y[72], int32_T iy0);

#endif

//
// File trailer for generated code.
//
// [EOF]
//
