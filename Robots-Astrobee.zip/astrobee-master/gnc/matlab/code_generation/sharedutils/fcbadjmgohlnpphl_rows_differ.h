//
// File: fcbadjmgohlnpphl_rows_differ.h
//
// Code generated for Simulink model 'sim_model_lib0'.
//
// Model version                  : 1.1142
// Simulink Coder version         : 8.11 (R2016b) 25-Aug-2016
// C/C++ source code generated on : Tue Oct 16 10:08:00 2018
//
#ifndef SHARE_fcbadjmgohlnpphl_rows_differ
#define SHARE_fcbadjmgohlnpphl_rows_differ
#include "rtwtypes.h"

extern boolean_T fcbadjmgohlnpphl_rows_differ(const real32_T b_data[], const
  int32_T b_sizes[2], int32_T k0, int32_T k);

#endif

//
// File trailer for generated code.
//
// [EOF]
//
