//
// File: fcbijmgdglngglfc_xgeqrf.h
//
// Code generated for Simulink model 'est_estimator'.
//
// Model version                  : 1.1142
// Simulink Coder version         : 8.11 (R2016b) 25-Aug-2016
// C/C++ source code generated on : Tue Oct 16 10:06:07 2018
//
#ifndef SHARE_fcbijmgdglngglfc_xgeqrf
#define SHARE_fcbijmgdglngglfc_xgeqrf
#include "rtwtypes.h"

extern void fcbijmgdglngglfc_xgeqrf(real32_T A_data[], int32_T A_sizes[2],
  real32_T tau_data[], int32_T *tau_sizes);

#endif

//
// File trailer for generated code.
//
// [EOF]
//
