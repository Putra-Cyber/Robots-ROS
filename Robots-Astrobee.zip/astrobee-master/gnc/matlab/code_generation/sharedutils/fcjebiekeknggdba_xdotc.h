//
// File: fcjebiekeknggdba_xdotc.h
//
// Code generated for Simulink model 'est_estimator'.
//
// Model version                  : 1.1142
// Simulink Coder version         : 8.11 (R2016b) 25-Aug-2016
// C/C++ source code generated on : Tue Oct 16 10:06:07 2018
//
#ifndef SHARE_fcjebiekeknggdba_xdotc
#define SHARE_fcjebiekeknggdba_xdotc
#include "rtwtypes.h"

extern real32_T fcjebiekeknggdba_xdotc(int32_T n, const real32_T x_data[],
  int32_T ix0, const real32_T y_data[], int32_T iy0);

#endif

//
// File trailer for generated code.
//
// [EOF]
//
